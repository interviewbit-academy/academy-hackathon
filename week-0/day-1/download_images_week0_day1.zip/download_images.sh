#!/bin/bash

user=$(whoami)
download_directory=/home/${user}/Downloads/Batman
url=https://wallpapercave.com/dark-knight-hd-wallpaper

# -nd : stops creating any new directories
# -r : downloads recursively
# -P : specifies a path where to download files
# -A : files types to be retrieved

wget -nd -r -P $download_directory -A jpeg,jpg $url


